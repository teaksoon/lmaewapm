#include <avr/io.h>
#define ADD_I2C_W   0x78 // i2c Write Address(SSD1306 is a write only device)
#define ADD_PAGE    0x22 // select row - ( 0 to   7 ) each is 8 pixel vert
#define ADD_COL     0x21 // select col - ( 0 to 127 ) each is 1 pixel horz
#define ADD_DATA    0x40 // Address to start data transmission
#define ADD_COMM    0x00 // Address to start Command

uint8_t _io_pinSDA = PB0; // Default to PB0 ( Arduino Pin 8 )
uint8_t _io_pinSCL = PB1; // Default to PB1 ( Arduino Pin 9 )

// --- start function declaration ---
void _io_oled_i2c_start();
void _io_oled_i2c_stop();
uint8_t io_oled_i2c_write_byte(uint8_t dat);
void _io_oled_setRowCol(uint8_t _row, uint8_t _col );
void io_oled_pinSelect(uint8_t _new_pinSDA, uint8_t _new_pinSCL);
void io_oled_begin();
void io_oled_clearScreen();
void io_oled_showBitmap(uint8_t _row, uint8_t _col, uint8_t *_bitmap, uint8_t _len, uint8_t _len_idx);
void io_oled_showChar(uint8_t _row, uint8_t _col, char _cha);
void io_oled_showChar_L(uint8_t _row, uint8_t _col, char _cha) ;
// --- end function declration ---

const char _io_oled_font_number[] = {
 0b00111110,0b01010001,0b01001001,0b01000101,0b00111110,  /* 0 (ascii 48) */
 0b00000000,0b01000010,0b01111111,0b01000000,0b00000000,  /* 1 */
 0b01000010,0b01100001,0b01010001,0b01001001,0b01000110,  /* 2 */
 0b00100001,0b01000001,0b01000101,0b01001011,0b00110001,  /* 3 */
 0b00011000,0b00010100,0b00010010,0b01111111,0b00010000,  /* 4 */
 0b00100111,0b01000101,0b01000101,0b01000101,0b00111001,  /* 5 */
 0b00111100,0b01001010,0b01001001,0b01001001,0b00110000,  /* 6 */
 0b00000001,0b01110001,0b00001001,0b00000101,0b00000011,  /* 7 */
 0b00110110,0b01001001,0b01001001,0b01001001,0b00110110,  /* 8 */
 0b00000110,0b01001001,0b01001001,0b00101001,0b00011110   /* 9 (ascii 57) */
};  

void _io_oled_i2c_start() {
  (PORTB |= (1<< _io_pinSDA)); __asm__("NOP");
  (PORTB |= (1<< _io_pinSCL)); __asm__("NOP");
  (PORTB &= ~(1<<_io_pinSDA)); __asm__("NOP");
  (PORTB &= ~(1<<_io_pinSCL)); __asm__("NOP");
}

void _io_oled_i2c_stop() {
  (PORTB &= ~(1<<_io_pinSDA)); __asm__("NOP");
  (PORTB |= (1<< _io_pinSCL)); __asm__("NOP");
  (PORTB |= (1<< _io_pinSDA)); __asm__("NOP");
}

uint8_t io_oled_i2c_write_byte(uint8_t dat) {
uint8_t ack = 0;  // 0=successful, 1=f ailed
  for(uint8_t i=0; i < 8; i++) {
    (dat & 0x80) ? (PORTB |= (1<< _io_pinSDA)) : (PORTB &= ~(1<< _io_pinSDA));
    dat<<=1;      
     __asm__("NOP");
     
    (PORTB |= (1<< _io_pinSCL));  __asm__("NOP");
    (PORTB &= ~(1<<_io_pinSCL));  __asm__("NOP");
  }
  (PORTB |= (1<<_io_pinSDA));
  (PORTB |= (1<<_io_pinSCL)); __asm__("NOP");
  (PORTB &= ~(1<<_io_pinSCL));
  return ack; 
}

void _io_oled_i2c_startComm() { 
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_COMM);
}

void _io_oled_i2c_startData() {
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA); 
}

void _io_oled_setRowCol(uint8_t _row, uint8_t _col ) { 
  _io_oled_i2c_startComm();
  io_oled_i2c_write_byte(ADD_PAGE); // Starting Row position
  io_oled_i2c_write_byte(_row);io_oled_i2c_write_byte(7);
  io_oled_i2c_write_byte(ADD_COL);  // Starting Col position
  io_oled_i2c_write_byte(_col);io_oled_i2c_write_byte(127);  
  _io_oled_i2c_stop();
}

void io_oled_pinSelect(uint8_t _new_pinSDA, uint8_t _new_pinSCL) {
  _io_pinSDA = _new_pinSDA;
  _io_pinSCL = _new_pinSCL;  
}

void io_oled_begin() {
uint8_t initData[26]= { 
  0xAE,       // 0xAE Display OFF
  0xD5,0x80,  // 0xD5 Display Clock Div
  0xA8,0x3F,  // 0xA8 Set Multiplex: 0x1F for 128x32, 0x3F for 128x64
  0xD3,0x00,  // 0xD3 Set Display offset 0
  0x40,       // 0x40 Start Line 0
  0x8D,0x14,  // 0x8D Set Charge pump Enabled,internal VCC
  0x20,0x00,  // 0x20 Set Memory Mode: 0x00 for H, 0x01 for V
  0xA1,       // 0xA1 Rotate 180
  0xC8,       // 0xC8 Com Scan Dec
  0xDA,0x12,  // 0xDA Set COM Pins, 0x12 for h=64 or 0x02 for h=32
  0x81,0xCF,  // 0x81 Set Contrast
  0xD9,0xF1,  // 0xD9 Set pre-charge period
  0xDB,0x40,  // 0xDB Set vcom detect
  0xA4,       // 0xA4 all pixel 0N = A4, all pixel OFF=A5
  0xA6,       // 0xA6 Normal Display
  0x2E,       // 0x2E No Scroll
  0xAF        // 0xAF Display on
  };
  
  DDRB |= ( (1<<_io_pinSDA) | (1<<_io_pinSCL) );  
  _io_oled_i2c_start(); // Start the i2c communication

  // Intital Setup Values for the SSD1306 I2C OLED 64x128 pixel only
  for (uint8_t i=0; i < 26; i++) {
    _io_oled_i2c_start();
    io_oled_i2c_write_byte(ADD_I2C_W);
    io_oled_i2c_write_byte(ADD_COMM);
    io_oled_i2c_write_byte(initData[i]);
    _io_oled_i2c_stop();    
  } 
  io_oled_clearScreen(); // Clear screen and ready for use
}

void io_oled_clearScreen() {
  _io_oled_setRowCol(0,0); 
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA); 
  for (uint8_t r=0; r < 8; r++) {
    for (uint8_t c=0; c < 128; c++) {
      io_oled_i2c_write_byte(0);
    }
  } 
  _io_oled_i2c_stop();
  _io_oled_setRowCol(0,0);
}

void io_oled_showBitmap(uint8_t _row, uint8_t _col, uint8_t *_bitmap, uint8_t _len, uint8_t _len_idx) {
  _io_oled_setRowCol(_row,_col);
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA);
  for (uint8_t i=0; i < _len; i++) {
    io_oled_i2c_write_byte(_bitmap[i+_len_idx]);
  }
  _io_oled_i2c_stop();
}  

void io_oled_showChar(uint8_t _row, uint8_t _col, char _cha) {
  
  if (_cha < 48 || _cha > 57 ) return; // Ascii 48 to 57 only, Ignore the rest
  
  _io_oled_setRowCol(_row,_col);  
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA);
  for (int i=0; i < 5; i++) {  // EACH FONT is 5 byte in FONT ARRAY
    io_oled_i2c_write_byte(_io_oled_font_number[((_cha-48)*5)+i]); 
  } 
  _io_oled_i2c_stop();   
}

void io_oled_showChar_L(uint8_t _row, uint8_t _col, char _cha) {
char cTmp;  
char enlargeMask[]= {
  0b00000000,0b00000011,0b00001100,0b00001111,0b00110000,0b00110011,0b00111100,0b00111111,
  0b11000000,0b11000011,0b11001100,0b11001111,0b11110000,0b11110011,0b11111100,0b11111111
  };
  
  if (_cha < 48 || _cha > 57 ) return; // Ascii 48 to 57 only, Ignore the rest

  // Double Size, Top Part
  _io_oled_setRowCol(_row,_col); 
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA);
  for (uint8_t i=0; i < 5; i++) {   
    cTmp = _io_oled_font_number[((_cha-48)*5)+i];
    cTmp = cTmp & 0x0F;       // store LOW BYTE
    cTmp = enlargeMask[cTmp]; // mapped into Enlargement Mask
    io_oled_i2c_write_byte(cTmp); // write to OLED
    io_oled_i2c_write_byte(cTmp); // same thing, to double size
  }
  _io_oled_i2c_stop(); 
 
  // Double Size, Bottom Part        
  _io_oled_setRowCol(_row+1,_col); 
  _io_oled_i2c_start();
  io_oled_i2c_write_byte(ADD_I2C_W);
  io_oled_i2c_write_byte(ADD_DATA); 
  for (uint8_t i=0; i < 5; i++) {
    cTmp = _io_oled_font_number[((_cha-48)*5)+i];
    cTmp = (cTmp&0xF0) >> 4 ; // store HIGH BYTE
    cTmp = enlargeMask[cTmp]; // mapped into Enlargement Mask
    io_oled_i2c_write_byte(cTmp); // write to OLED
    io_oled_i2c_write_byte(cTmp); // same thing, to double size      
  } 
  _io_oled_i2c_stop();
}
